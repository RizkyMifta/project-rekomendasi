-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 11 Jun 2026 pada 08.13
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `parfum_db`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `parfum`
--

CREATE TABLE `parfum` (
  `id` int(11) NOT NULL,
  `nama_parfum` varchar(100) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `foto` varchar(100) DEFAULT NULL,
  `top_notes` text DEFAULT NULL,
  `middle_notes` text DEFAULT NULL,
  `base_notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `parfum`
--

INSERT INTO `parfum` (`id`, `nama_parfum`, `brand`, `foto`, `top_notes`, `middle_notes`, `base_notes`) VALUES
(21, 'Glitch', 'Mykonos', '1.jpg', 'Sicilian bergamot, apple', 'Lavender, lily of the valley', 'White musk, cedarwood'),
(22, 'Invade', 'Mykonos', '2.jpg', 'Pink pepper, lavender', 'Cashmeran, cinnamon', 'Amber, vanilla'),
(23, 'Cafe Drops', 'Mykonos', '3.jpg', 'Orchid, jasmine, coffee', 'Vanilla, caramel', 'Amber, musk'),
(24, 'Pink Drops', 'Mykonos', '4.jpg', 'Strawberry, almond', 'Milk, heliotrope', 'Vanilla, white musk'),
(25, 'Pandan Sticky Rice', 'Mykonos', '5.jpg', 'Rice, almond', 'Jasmine, pandan', 'Ambery, sandalwood'),
(26, 'Artemis', 'HMNS', '6', 'Bergamot, lemon', 'Neroli, orange blossom', 'Musk, amber'),
(27, 'Alpha', 'HMNS', '7', 'Apple, cinnamon', 'Lavender', 'Vanilla, woods'),
(28, 'Farhampton', 'HMNS', '8.jpg', 'Bergamot, cardamom', 'Iris, violet', 'Leather, sandalwood'),
(29, 'Orgasm', 'HMNS', '9.jpg', 'Pear, red berries', 'Jasmine, rose', 'Vanilla, patchouli'),
(30, 'Saff & Co Santal', 'Saff & Co', '10.jpg', 'Cardamom, fig', 'Iris, violet', 'Sandalwood'),
(31, 'Oaken Lab Sanctum', 'Oaken Lab', '11.jpg\r\n', 'Bergamot', 'Rose, patchouli', 'Amber, oud'),
(32, 'Carl & Claire Lune', 'Carl & Claire', '12', 'Lemon, pear', 'Jasmine', 'Musk, vanilla'),
(33, 'Carl & Claire Muse', 'Carl & Claire', '13', 'Orange blossom', 'Tuberose', 'Musk'),
(34, 'Kahf Invigorating', 'Kahf', '14', 'Mint, lemon', 'Green tea', 'Cedarwood'),
(35, 'Etre Aroma Gourmand', 'Etre', '15.jpg', 'Coffee, cocoa', 'Vanilla', 'Caramel'),
(41, 'Onix Shadow', 'Onix', '16', 'Pepper, Bergamot', 'Leather', 'Patchouli'),
(42, 'Alien Objects Terra', 'Alien Objects', '17', 'Grapefruit', 'Vetiver', 'Amber'),
(43, 'Izzi Classic', 'Izzi', '18', 'Orange', 'Lavender', 'Musk'),
(44, 'Project 1945 Signature', 'Project 1945', '19', 'Bergamot', 'Jasmine', 'Sandalwood'),
(45, 'Heura Floral Musk', 'Heura', '20', 'Rose', 'Peony', 'White Musk');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `parfum`
--
ALTER TABLE `parfum`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `parfum`
--
ALTER TABLE `parfum`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
